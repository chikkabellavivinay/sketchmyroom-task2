<?php
function createUser($userid, $uname , $email, $password){
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'task2';	
	
	$conn = mysql_connect($dbhost,$dbuser,$dbpass,$dbname)or die("mysql connection error:". mysql_error());
	$db = mysql_select_db('task2');
	$uname = mysql_real_escape_string($uname);
	$create = "INSERT INTO register(userid, username, email, password) VALUES('{$userid}', '{$uname}', '{$email}','{$password}')";
	$result = mysql_query($create);
	if(!$result){
		die("Invalid query ".mysql_error());
	}
	mysql_close($conn);
	//return $slug;
}




function createEvent($publisher, $eventname,$date,$address,$category,$eventid){
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'task2';
	$conn = mysql_connect($dbhost,$dbuser,$dbpass,$dbname)or die("mysql connection error:". mysql_error());
	$db = mysql_select_db('task2');
	$slug = mysql_real_escape_string($slug);
	$create = "INSERT INTO event(PUBLISHER, EVENT_NAME, EVENT_DATE,EVENT_ADDRESS,CATEGORY,EVENT_ID) VALUES('{$publisher}', '{$eventname}','{$date}','{$address}','{$category}','{$eventid}')";
	$result = mysql_query($create);
	if(!$result){
		die("Invalid query ".mysql_error());
	}
	mysql_close($conn);
	return $slug;
}

function createQuery($username,$email,$query){
	$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'task2';
	$conn = mysql_connect($dbhost,$dbuser,$dbpass,$dbname)or die("mysql connection error:". mysql_error());
	$db = mysql_select_db('task2');
	$message = mysql_real_escape_string($query);
	$create = "INSERT INTO queries(username, email, query ) VALUES(DEFAULT, '{$username}', '{$email}', '{$query}')";
	$result = mysql_query($create);
	if(!$result){
		die("Invalid query ".mysql_error());
	}
	mysql_close($conn);
}

function setUserSession($user){
	require_once('configuration.php');
	$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'task2';
	$conn = mysql_connect($dbhost,$dbuser,$dbpass,$dbname)or die("mysql connection error:". mysql_error());
	$db = mysql_select_db('task2');
	//('$dbname',$conn);
	
	$sql = "SELECT * FROM register where username = '{$username}'";
	$result = mysql_query($sql);
	if(!$result){
		die("Invalid query ".mysql_error());
	}else{
		while($row = mysql_fetch_array($result)){
			$_SESSION['user_id'] = $row['userid'];
		}
	}
	mysql_close($conn);
}

function deletequery($query_id){
	$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'task2';
	$conn = mysql_connect($dbhost,$dbuser,$dbpass,$dbname)or die("mysql connection error:". mysql_error());
	$db = mysql_select_db('vinay_blog');
	$sql = "DELETE FROM queries where query = '{$query_id}'";
	$result = mysql_query($sql);
	if(!$result){
		die("Invalid query ".mysql_error());
	}
	mysql_close($conn);
}

function deleteEvent($event_id){
	$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'task2';
	$conn = mysql_connect($dbhost,$dbuser,$dbpass,$dbname)or die("mysql connection error:". mysql_error());
	$db = mysql_select_db('vinay_blog');
	$sql = "DELETE FROM events where id = '{$eventid}'";
	$result = mysql_query($sql);
	if(!$result){
		die("Invalid query ".mysql_error());
	}
	mysql_close($conn);
}
?>