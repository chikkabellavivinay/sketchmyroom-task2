-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2016 at 01:15 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task2`
--

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `PUBLISHER` text NOT NULL,
  `EVENT_DATE` date NOT NULL,
  `EVENT_ADDRESS` varchar(2000) NOT NULL,
  `CATEGORY` text NOT NULL,
  `EVENT_NAME` text NOT NULL,
  `id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`PUBLISHER`, `EVENT_DATE`, `EVENT_ADDRESS`, `CATEGORY`, `EVENT_NAME`, `id`) VALUES
('username', '0000-00-00', 'addressevent', 'category', 'about', 0),
('username', '0000-00-00', 'addressevent', 'category', 'about', 0),
('username', '0000-00-00', 'addressevent', 'category', 'about', 0),
('', '0000-00-00', '', '', '', 0),
('root', '0000-00-00', '', '', '', 0),
('root', '0000-00-00', '', '', '', 0),
('vinay', '2016-11-22', 'bangalore', 'birthday', 'Birthday', 0),
('root', '0000-00-00', '', '', '', 0),
('root', '0000-00-00', '', '', '', 0),
('root', '0000-00-00', '', '', '', 0),
('root', '0000-00-00', '', '', '', 0),
('root', '0000-00-00', '', '', '', 0),
('root', '0000-00-00', '', '', '', 0),
('root', '0000-00-00', '', '', '', 0),
('root', '0000-00-00', '', '', '', 0),
('root', '0000-00-00', '', '', '', 0),
('root', '0000-00-00', '', '', '', 0),
('', '0000-00-00', '', '', '', 0),
('', '0000-00-00', '', '', '', 0),
('', '0000-00-00', '', '', '', 0),
('', '0000-00-00', '', '', '', 0),
('', '0000-00-00', '', '', '', 0),
('', '0000-00-00', '', '', '', 0),
('', '0000-00-00', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `queries`
--

CREATE TABLE `queries` (
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `query` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `userid` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`userid`, `username`, `email`, `password`) VALUES
(1, 'Vinay S', 'vinay.s.9993@gmail.com', '084c752c33c43d09a9e46c26979486dc'),
(2, 'Ganesha', 'ganesha@gmail.com', '084c752c33c43d09a9e46c26979486dc');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `userid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
