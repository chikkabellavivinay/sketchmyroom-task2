<?php 

require('configuration.php');
if(isset($_POST["username"]) || isset($_POST["email"]) || isset($_POST["password"])){
	$username = $_POST["username"];
	$email = $_POST["email"];
	$password = $_POST["password"];
	
	// Check if user inputed special char for dangerous behavior.
	
	$username = htmlspecialchars($username);
	$email = htmlspecialchars($email);
	$password = md5(htmlspecialchars($password));
	
}



//Check do we have username and password
if(isset($_POST['submit'])){
	if($username == "" || $email == "" || $password == "" ){
		echo("Please go back and fill in all the required fields");
	}else{
require_once('configuration.php');
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'task2';
		$conn = mysql_connect($dbhost,$dbuser,$dbpass,$dbname) or die("MYSQL error:".mysql_error());
		$db = mysql_select_db('task2');
		if (!$db){
			echo("Failed to connect to MySQL database.");
		}else{
			$checkquery = "SELECT * FROM register WHERE username = '{$username}'";
			$results = mysql_query($checkquery);
			$num_rows = mysql_num_rows($results);
			if($num_rows > 0){
			  echo("Username Already Taken");
			  die();
			}else{
			  $username = ltrim($username);
			  $sqlquery = "INSERT INTO register(userID, username, email, password) VALUES(DEFAULT, '{$username}', '{$email}', '{$password}')";
			  $result = mysql_query($sqlquery);
			  if(!$result){
				  die("Invalid query ".mysql_error());
			  }
			}
		}
		mysql_close($conn);
		$_SESSION['username'] = $username;
		$_SESSION['login'] = true;
		header('Location: index.php');
	}
}
?>

<!DOCTYPE html>
<html content-width="auto" lang="en">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<head>
    <title>EVENTHOST</title>
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" type="text/css" src="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" src="css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" src="css/bootstrap-theme.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="js/jqueryscript.js"></script>

    <style>
        body {
            background-image: url("images/charcoal.jpg");
        }
        
        #register {
            margin-right: 60px;
        }
		
		img{
		overflow:hidden;
		}
		
		*{margin: 0; padding: 0; box-sizing: border-box}

		.col {
			height: 100px;
			border: 1px solid white;
			}
		.col {
			float: left;
			}
		.row {
			width: 100%;
			}
		.col.half {
			width: 50%;
			}

		
		.navbar-contact{
		background-color:skyblue;
		color:red;
		font-family:Comic Sans MS;
		font-size:30px;
		font-style:regular;
		float:right;
		}		
		textarea{		
		max-width:500px;
		max-height:90px;
		}
		
		#q1,#q2{
		max-width:500px;
		}
		
		#aboutme,#foot{
		font-family:normal;
		font-size:20px;
		}
		#fb,#twi{
		max-width:40px;
		max-height:40px;		
		}
		
    </style>
</head>

<body id="image">
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li><a class="navbar-brand" href="<?php header('index.php'); ?>">Home</a>
                    </li>
                    <li><a href="index.php#events">EVENTS</a>
                    </li>
                    <li><a href="index.php#queries">QUERIES</a>
                    </li>
                    <li><a href="index.php#about">ABOUT</a>
                    </li>
                    
                </ul>

                <form action="login.php" method="post">
                    <div class="dropdown nav navbar-right">
                        <button class="btn btn-default dropdown-toggle" type="button" id="login" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                            LOGIN
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu col-lg-6" aria-labelledby="dropdownMenu1" style="width:50px;">
                            <input type="email" name="email" placeholder="enter your email id" class="form-control" required/>
                            <input type="password" name="password" placeholder="enter password" class="form-control" required />
                            <li role="seperator" class="divider"></li>
                            <input type="submit" class="btn btn-success" value="login" name="login"/>
                        </ul>
                    </div>
                </form>

                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                    <div class="dropdown nav navbar-right">
                        <button class="btn btn-default dropdown-toggle" type="button" id="register" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                            REGISTER
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu col-lg-6" aria-labelledby="dropdownMenu1" style="width:50px;">
                            <input type="text" placeholder="enter full name" class="form-control" name='username' id='username'required/>
                            <input type="email" placeholder="enter your email id" class="form-control" name='email' id='email' required/>
                            <input type="password" placeholder="enter password" class="form-control" name='password' id='password' required />
                            <input type="password" placeholder="retype password" class="form-control" required />
                            <li role="seperator" class="divider"></li>
                            <input type="submit" class="btn btn-success" value="submit" name="submit"/>
                        </ul>
                    </div>
                </form>
				<form action="logout.php" method="post">                    
                        <button class="btn btn-danger" type="button" name="logout" id="logout" value="logout" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                            LOGOUT
                        </button>                    
                </form>
            </div>
        </div>
    </nav>

    <!--top image	-->
    <div class="container" id="home">

        <div class="col-md-12">

            <div class="thumbnail">
					<center><p>HAPPENINGS AROUND YOU</p></center>
                <img src="images/Party1.jpg">

            </div>
        </div>
    </div>
    <!--top ends here-->

    <!--middle-->
    <div class="row" id="home">
        <div class="col-md-4">
            <div class="panel-heading">
                <button class="btn btn-default"><a href="bangaloreview.php" id="events">VIEW BANGALORE EVENTS</button></a>
				<button class="btn btn-default"><a href="bangalorecreate.php" id="events">CREATE EVENT</button></a></div>
            <div class="thumbnail">
                <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="false">
                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel" data-slide-to="1"></li>
                        <li data-target="#myCarousel" data-slide-to="2"></li>
                    </ol>

                    <div class="carousel-inner">
                        <div class="item active">
                            <img src="images/bangalore/bangalore.jpg">
                        </div>
                        <div class="item">
                            <img src="images/bangalore/bangalore2.jpg" alt="Chania">
                        </div>
                        <div class="item">
                            <img src="images/bangalore/bangalore3.jpg" alt="Flower">
                        </div>
                    </div>
                    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="panel-heading">
                <button class="btn btn-default"><a href="pagenf.html">TUMKUR EVENTS</button></a></div>
            <div class="thumbnail">
                <div id="myCarousel2" class="carousel slide" data-ride="carousel" data-interval="false">
                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#myCarousel2" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel2" data-slide-to="1"></li>
                        <li data-target="#myCarousel2" data-slide-to="2"></li>
                    </ol>

                    <div class="carousel-inner">
                        <div class="item active">
                            <img src="images/tumkur/tumkur.jpg">
                        </div>
                        <div class="item">
                            <img src="images/tumkur/tumkur1.jpg" alt="Chania">
                        </div>
                        <div class="item">
                            <img src="images/tumkur/tumkur2.jpg" alt="Chania">
                        </div>
                    </div>
                    <a class="left carousel-control" href="#myCarousel2" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#myCarousel2" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="panel-heading">
                <button class="btn btn-default"><a href="pagenf.html">MYSORE EVENTS</a></button>
            </div>
            <div class="thumbnail">
                <div id="myCarousel3" class="carousel slide" data-ride="carousel" data-interval="false">
                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#myCarousel3" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel3" data-slide-to="1"></li>
                        <li data-target="#myCarousel3" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="item active">
                            <img src="images/mysore/mysore.jpg">
                        </div>
                        <div class="item">
                            <img src="images/mysore/mysore1.jpg" alt="Chania">
                        </div>
                        <div class="item">
                            <img src="images/mysore/mysore2.jpg" alt="Chania">
                        </div>
                    </div>
                    <a class="left carousel-control" href="#myCarousel3" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#myCarousel3" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!--containerclassendshere-->
    <!--middle ends here-->
	<form>
<div class="thumbnail col-md-12" id="query">
<div class="form-group col-md-6">
<header><h3><a id="queries" name="queries">QUERIES</a></h3></header>
<input type="text" id="q1" class="form-control" placeholder="enter your name">
<input type="email" id="q2" class="form-control" placeholder="enter your email">
<textarea class="form-control" rows="5" placeholder="enter your query"></textarea>
<button type="submit" value="SEND" name="SEND" class="btn btn-success">SEND</button>
</div>

<div class="form-group col-md-6">
<header><h3><a id="about" name="about">ABOUT</a></h3></header>
<hr>
<p id="aboutme">I am Vinay, a M.Sc. Graduate from Bangalore University. This is a backend task UI<br/>Catch me on..</p>
<div>
<a href="https://facebook.com/chikkabellavivinay" id="fb"><image src="images/contact/fb.jpg" id="fb"></a>
<a href="https://twitter.com/naanuvinay" id="twi"><image src="images/contact/twitter.jpg" id="twi"></a>
</div>
<div class="glyphicon glyphicon-hand-up"><a href="#home">return to top</a></div>
</div>
</div>
</form>

    	
           <div class="panel" id="footer">
		      <p class="text-right" id="foot">&copy;vinay somasundaraiah</p>
           </div>
<script>
    
</script>   
</body>
</html>