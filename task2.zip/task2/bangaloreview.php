<!DOCTYPE html>
<html>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "task2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT PUBLISHER, EVENT_NAME, EVENT_DATE, EVENT_ADDRESS, CATEGORY FROM event";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<br> EVENT DATE: ". $row["EVENT_DATE"]. " - PUBLISHER Named: ". $row["PUBLISHER"]. "HAS PUBLISHED EVENT - " . $row["EVENT_NAME"] . "- AT THE FOLLOWING LOCATION "."<br>" . $row["EVENT_ADDRESS"] ." THE CATEGORY OF THE EVENT IS" . $row["CATEGORY"] ."<br>";
     }
} else {
     echo "0 results";
}

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$conn->close();
?>  
<button><a href="index.php">BACK TO HOME</a></button>
</body>
</html>