<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "task2";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$publisher = "";
$date = "";
$addressevent = "";
$category = "";
$about = "";


$sql = "INSERT INTO event (PUBLISHER, EVENT_DATE, EVENT_ADDRESS, CATEGORY ,EVENT_NAME )
VALUES('{$publisher}', '{$date}', '{$addressevent}', '{$category}', '{$about}')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" src="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" src="css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" src="css/bootstrap-theme.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="js/jqueryscript.js"></script>
	<style>
		textarea{
			max-width:500px;
			max-height:200px;
		}
		
		.well{
			background-color:skyblue;
		}
		body{
			background-image:url("images/Events.jpeg");
		}
	</style>
</head>
	<body>
	<div class="container">

	<div class="nav navbar-default col-lg-12"><center>CREATE EVENT</center></div>
		<div class="well col-md-12">
		<div class="form-group">
		<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
		<table><tbody>
		<tr>
		<td><label for="USERNAME" value="username" class="label label-info">ENTER YOUR FULL NAME:</label></td>
		<td><input type="text" id="publisher" name="publisher" placeholder="Enter your full name" class="form-control"/><td>
		</tr>
	<tr>	
<td><label for="DATE" value="DATE" class="label label-info">ENTER EVENT DATE:</label></td>
<td><input type="date" id="date" name="date" placeholder="enter event date" class="form-control"/></td>
</tr>
<tr>
<td><label for="ADDRESS" value="ADDRESS" class="label label-info">ENTER ADDRESS OF EVENT:</label> </td> 
<td><textarea name="addressevent" id= "addressevent" placeholder="enter events full address" class="form-control" rows="10" cols="20" aria-describedby="basic-addon1"></textarea></td>
</tr>
<tr>
<td><label for="CATEGORY" value="CATEGORY" class="label label-info">SELECT A CATEGORY:</label></td>
<td>
<input list="category" class="form-control" name="category" id="category">
<datalist id="category">
<option value="BIRTHDAY">
<option value="RECEPTION">
<option value="MARRIAGE">
<option value="DEVOTIONAL">
</datalist></td>
</tr>
<tr>
<td><label for="ABOUT" id="about" value="ABOUT" class="label label-info" name="details">ENTER DETAILS ABOUT EVENT:</label></td>
<td><textarea name="about" placeholder="enter details about event" class="form-control" rows="10" cols="100"></textarea></td>
</tr>
<tr>
<td><input type="submit" value="CREATE" name="create" class="btn btn-success"/><td>
<tr>
</tbody></table></form></div></div></div>
</body>
</html>