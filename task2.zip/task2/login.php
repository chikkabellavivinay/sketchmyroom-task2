<?php
session_start(); 
require('configuration.php');

if(isset($_POST['login'])){
	$email = $_POST['email'];
	$password = md5(htmlspecialchars($_POST['password']));
	//$password = ($_POST['password']);
	//echo $password."<br>";
	$conn = mysql_connect($dbhost,$dbuser,$dbpass,$dbname)or die("Mysql connection error:". mysql_error());
	$db = mysql_select_db('task2');
	$query = "SELECT * FROM register WHERE email = '{$email}' AND password = '{$password}'";
	$result = mysql_query($query);
	if(!$result){
		die("Invalid query ".mysql_error());
	}
	$num_rows = mysql_num_rows($result);
	if($num_rows > 0){
		$row = mysql_fetch_array($result);
		$_SESSION['email'] = $row['email'];
		$_SESSION['user_id'] = $row['userID'];
		$_SESSION['login'] = true;
		header('Location:index.php');
	}else{
		echo("Login details wrong. Go back and retry.");
	}
	mysql_close($conn);
}
?>